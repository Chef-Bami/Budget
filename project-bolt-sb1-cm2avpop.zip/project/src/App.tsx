import React, { useState, useEffect } from 'react';
import { Plus, Calendar } from 'lucide-react';
import Header from './components/Header';
import TransactionForm from './components/TransactionForm';
import Dashboard from './components/Dashboard';
import Chart from './components/Chart';
import TransactionList from './components/TransactionList';
import { BudgetData, Transaction } from './types';
import { loadBudgetData, saveBudgetData } from './utils/storage';
import { calculateMonthlyData, getCurrentMonth, formatMonth } from './utils/calculations';

function App() {
  const [budgetData, setBudgetData] = useState<BudgetData>({ transactions: [], categories: { income: [], expense: [] } });
  const [selectedMonth, setSelectedMonth] = useState<string>(getCurrentMonth());
  const [showIncomeForm, setShowIncomeForm] = useState(false);
  const [showExpenseForm, setShowExpenseForm] = useState(false);

  useEffect(() => {
    setBudgetData(loadBudgetData());
  }, []);

  useEffect(() => {
    saveBudgetData(budgetData);
  }, [budgetData]);

  const addTransaction = (transactionData: Omit<Transaction, 'id'>) => {
    const newTransaction: Transaction = {
      ...transactionData,
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9)
    };

    setBudgetData(prev => ({
      ...prev,
      transactions: [...prev.transactions, newTransaction]
    }));
  };

  const deleteTransaction = (id: string) => {
    setBudgetData(prev => ({
      ...prev,
      transactions: prev.transactions.filter(t => t.id !== id)
    }));
  };

  const monthlyData = calculateMonthlyData(budgetData.transactions);
  const monthTransactions = budgetData.transactions.filter(t => 
    t.date.startsWith(selectedMonth)
  );

  const availableMonths = [
    ...new Set([
      getCurrentMonth(),
      ...budgetData.transactions.map(t => t.date.substring(0, 7))
    ])
  ].sort().reverse();

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Contrôles */}
        <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center mb-8">
          <div className="flex items-center gap-3">
            <Calendar className="w-5 h-5 text-gray-600" />
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {availableMonths.map(month => (
                <option key={month} value={month}>
                  {formatMonth(month)}
                </option>
              ))}
            </select>
          </div>
          
          <div className="flex gap-3">
            <button
              onClick={() => setShowIncomeForm(true)}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-md hover:shadow-lg transition-all duration-200"
            >
              <Plus className="w-4 h-4" />
              Ajouter un revenu
            </button>
            
            <button
              onClick={() => setShowExpenseForm(true)}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-md hover:shadow-lg transition-all duration-200"
            >
              <Plus className="w-4 h-4" />
              Ajouter une dépense
            </button>
          </div>
        </div>

        {/* Tableau de bord */}
        <Dashboard monthlyData={monthlyData} selectedMonth={selectedMonth} />

        {/* Contenu principal */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <Chart monthlyData={monthlyData} />
          </div>
          
          <div>
            <TransactionList 
              transactions={monthTransactions} 
              onDelete={deleteTransaction}
            />
          </div>
        </div>

        {/* Formulaires modaux */}
        <TransactionForm
          type="income"
          categories={budgetData.categories.income}
          onSubmit={addTransaction}
          isOpen={showIncomeForm}
          onClose={() => setShowIncomeForm(false)}
        />

        <TransactionForm
          type="expense"
          categories={budgetData.categories.expense}
          onSubmit={addTransaction}
          isOpen={showExpenseForm}
          onClose={() => setShowExpenseForm(false)}
        />
      </main>
    </div>
  );
}

export default App;
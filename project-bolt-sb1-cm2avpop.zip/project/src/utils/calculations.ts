import { Transaction, MonthlyData } from '../types';

export const calculateMonthlyData = (transactions: Transaction[]): MonthlyData[] => {
  const monthlyMap = new Map<string, { income: number; expenses: number }>();

  transactions.forEach(transaction => {
    const monthKey = transaction.date.substring(0, 7); // YYYY-MM
    
    if (!monthlyMap.has(monthKey)) {
      monthlyMap.set(monthKey, { income: 0, expenses: 0 });
    }

    const monthData = monthlyMap.get(monthKey)!;
    
    if (transaction.type === 'income') {
      monthData.income += transaction.amount;
    } else {
      monthData.expenses += transaction.amount;
    }
  });

  return Array.from(monthlyMap.entries())
    .map(([month, data]) => ({
      month,
      income: data.income,
      expenses: data.expenses,
      balance: data.income - data.expenses
    }))
    .sort((a, b) => a.month.localeCompare(b.month));
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('fr-FR', {
    style: 'currency',
    currency: 'EUR'
  }).format(amount);
};

export const formatMonth = (monthString: string): string => {
  const date = new Date(monthString + '-01');
  return date.toLocaleDateString('fr-FR', { 
    year: 'numeric', 
    month: 'long' 
  });
};

export const getCurrentMonth = (): string => {
  return new Date().toISOString().substring(0, 7);
};
import { BudgetData, DEFAULT_CATEGORIES } from '../types';

const STORAGE_KEY = 'budget-facile-data';

export const loadBudgetData = (): BudgetData => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const data = JSON.parse(stored);
      return {
        transactions: data.transactions || [],
        categories: { ...DEFAULT_CATEGORIES, ...data.categories }
      };
    }
  } catch (error) {
    console.error('Erreur lors du chargement des données:', error);
  }
  
  return {
    transactions: [],
    categories: DEFAULT_CATEGORIES
  };
};

export const saveBudgetData = (data: BudgetData): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error('Erreur lors de la sauvegarde des données:', error);
  }
};
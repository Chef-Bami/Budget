export interface Transaction {
  id: string;
  type: 'income' | 'expense';
  amount: number;
  category: string;
  description: string;
  date: string;
  isRecurring?: boolean;
}

export interface MonthlyData {
  month: string;
  income: number;
  expenses: number;
  balance: number;
}

export interface BudgetData {
  transactions: Transaction[];
  categories: {
    income: string[];
    expense: string[];
  };
}

export const DEFAULT_CATEGORIES = {
  income: ['Salaire', 'Freelance', 'Allocations', 'Investissements', 'Autres revenus'],
  expense: ['Alimentation', 'Logement', 'Transport', 'Loisirs', 'Santé', 'Vêtements', 'Éducation', 'Autres dépenses']
};
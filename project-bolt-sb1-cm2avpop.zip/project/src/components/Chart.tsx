import React from 'react';
import { MonthlyData } from '../types';
import { formatCurrency, formatMonth } from '../utils/calculations';

interface ChartProps {
  monthlyData: MonthlyData[];
}

const Chart: React.FC<ChartProps> = ({ monthlyData }) => {
  if (monthlyData.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Évolution mensuelle</h3>
        <div className="flex items-center justify-center h-64 text-gray-500">
          <p>Aucune donnée disponible</p>
        </div>
      </div>
    );
  }

  const maxAmount = Math.max(
    ...monthlyData.map(d => Math.max(d.income, d.expenses))
  );

  const recentData = monthlyData.slice(-6); // Afficher les 6 derniers mois

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-6">Évolution mensuelle</h3>
      
      <div className="space-y-6">
        {recentData.map((data, index) => (
          <div key={data.month} className="space-y-2">
            <div className="flex justify-between items-center text-sm">
              <span className="font-medium text-gray-700">{formatMonth(data.month)}</span>
              <div className="flex gap-4 text-xs">
                <span className="text-green-600">Revenus: {formatCurrency(data.income)}</span>
                <span className="text-red-600">Dépenses: {formatCurrency(data.expenses)}</span>
              </div>
            </div>
            
            <div className="flex gap-1 h-8">
              {/* Barre des revenus */}
              <div className="flex-1 bg-gray-100 rounded-l">
                <div
                  className="h-full bg-gradient-to-r from-green-400 to-green-500 rounded-l transition-all duration-500 ease-out"
                  style={{ width: `${maxAmount > 0 ? (data.income / maxAmount) * 100 : 0}%` }}
                  title={`Revenus: ${formatCurrency(data.income)}`}
                />
              </div>
              
              {/* Barre des dépenses */}
              <div className="flex-1 bg-gray-100 rounded-r">
                <div
                  className="h-full bg-gradient-to-r from-red-400 to-red-500 rounded-r transition-all duration-500 ease-out"
                  style={{ width: `${maxAmount > 0 ? (data.expenses / maxAmount) * 100 : 0}%` }}
                  title={`Dépenses: ${formatCurrency(data.expenses)}`}
                />
              </div>
            </div>
            
            <div className="text-right">
              <span className={`text-sm font-medium ${data.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                Solde: {formatCurrency(data.balance)}
              </span>
            </div>
          </div>
        ))}
      </div>

      <div className="flex justify-center items-center gap-6 mt-6 pt-4 border-t border-gray-200">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-gradient-to-r from-green-400 to-green-500 rounded"></div>
          <span className="text-sm text-gray-600">Revenus</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-gradient-to-r from-red-400 to-red-500 rounded"></div>
          <span className="text-sm text-gray-600">Dépenses</span>
        </div>
      </div>
    </div>
  );
};

export default Chart;
import React from 'react';
import { PiggyBank } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-lg">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center gap-3">
          <PiggyBank className="w-8 h-8" />
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">BudgetFacile</h1>
            <p className="text-blue-100 text-sm md:text-base">Gérez votre budget familial en toute simplicité</p>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
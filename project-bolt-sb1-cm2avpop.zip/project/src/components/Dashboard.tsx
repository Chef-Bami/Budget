import React from 'react';
import { TrendingUp, TrendingDown, DollarSign, Calendar } from 'lucide-react';
import { MonthlyData } from '../types';
import { formatCurrency, formatMonth } from '../utils/calculations';

interface DashboardProps {
  monthlyData: MonthlyData[];
  selectedMonth: string;
}

const Dashboard: React.FC<DashboardProps> = ({ monthlyData, selectedMonth }) => {
  const currentMonthData = monthlyData.find(d => d.month === selectedMonth) || {
    month: selectedMonth,
    income: 0,
    expenses: 0,
    balance: 0
  };

  const previousMonthData = monthlyData.find(d => {
    const prevMonth = new Date(selectedMonth + '-01');
    prevMonth.setMonth(prevMonth.getMonth() - 1);
    return d.month === prevMonth.toISOString().substring(0, 7);
  });

  const balanceColor = currentMonthData.balance >= 0 ? 'text-green-600' : 'text-red-600';
  const balanceIcon = currentMonthData.balance >= 0 ? TrendingUp : TrendingDown;
  const BalanceIcon = balanceIcon;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      <div className="bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-lg p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-green-600 text-sm font-medium uppercase tracking-wide">Revenus</p>
            <p className="text-2xl font-bold text-green-800">{formatCurrency(currentMonthData.income)}</p>
          </div>
          <TrendingUp className="w-8 h-8 text-green-500" />
        </div>
        <p className="text-green-600 text-sm mt-2">
          <Calendar className="w-4 h-4 inline mr-1" />
          {formatMonth(selectedMonth)}
        </p>
      </div>

      <div className="bg-gradient-to-br from-red-50 to-red-100 border border-red-200 rounded-lg p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-red-600 text-sm font-medium uppercase tracking-wide">Dépenses</p>
            <p className="text-2xl font-bold text-red-800">{formatCurrency(currentMonthData.expenses)}</p>
          </div>
          <TrendingDown className="w-8 h-8 text-red-500" />
        </div>
        <p className="text-red-600 text-sm mt-2">
          <Calendar className="w-4 h-4 inline mr-1" />
          {formatMonth(selectedMonth)}
        </p>
      </div>

      <div className={`bg-gradient-to-br ${currentMonthData.balance >= 0 ? 'from-blue-50 to-blue-100 border-blue-200' : 'from-orange-50 to-orange-100 border-orange-200'} border rounded-lg p-6`}>
        <div className="flex items-center justify-between">
          <div>
            <p className={`${currentMonthData.balance >= 0 ? 'text-blue-600' : 'text-orange-600'} text-sm font-medium uppercase tracking-wide`}>Solde</p>
            <p className={`text-2xl font-bold ${currentMonthData.balance >= 0 ? 'text-blue-800' : 'text-orange-800'}`}>
              {formatCurrency(currentMonthData.balance)}
            </p>
          </div>
          <BalanceIcon className={`w-8 h-8 ${currentMonthData.balance >= 0 ? 'text-blue-500' : 'text-orange-500'}`} />
        </div>
        <p className={`${currentMonthData.balance >= 0 ? 'text-blue-600' : 'text-orange-600'} text-sm mt-2`}>
          <DollarSign className="w-4 h-4 inline mr-1" />
          {currentMonthData.balance >= 0 ? 'Excédent' : 'Déficit'}
        </p>
      </div>
    </div>
  );
};

export default Dashboard;